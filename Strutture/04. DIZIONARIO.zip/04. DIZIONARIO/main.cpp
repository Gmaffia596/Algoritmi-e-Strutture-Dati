#include <iostream>
#include "hash_table.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) 
{
	hash_table <int,int> s(5);
	s.create();	
	return 0;
}
