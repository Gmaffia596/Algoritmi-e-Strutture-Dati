// LIBRERIA DI FUNZIONI HASH
#include <cstdlib>
using namespace std;

typedef unsigned int HashValue;

HashValue hash(string);

// HashValue hash(int);
// ...
